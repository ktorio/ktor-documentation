[//]: # (title: $TITLE)

## Feature 

## Description

## Usage

### Artifacts

The following artifact(s) need to be included in the build script to use this feature

<tabs>
    <tab title="Gradle (Groovy)">
        <code style="block" lang="Groovy" title="Sample">
        implementation "io.ktor.features.$ARTIFACT$:$VERSION$"
        </code>
    </tab>
    <tab title="Gradle (Kotlin)">
        <code style="block" lang="Kotlin" title="Sample">
            implementation("io.ktor.features.$ARTIFACT$:$VERSION$")
        </code>
    </tab>
    <tab title="Maven">
        <code style="block" lang="XML" title="Sample">
        <![CDATA[        
            <dependency>
                <scope>compile</scope>
                <groupId>io.ktor</groupId>
                <artifactId>$ARTIFACT$</artifactId>
                <version>$VERSION$</version>
            </dependency>
        ]]>
        </code>
   </tab>
</tabs>

## Options


