function message(msg) {
    alert(msg);
}