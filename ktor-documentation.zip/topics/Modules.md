[//]: # (title: Modules)


A Ktor Application consists of a series of one or more modules, each of which can house any kind of functionality. 

![App Diagram](app-diagram.svg)
 
 
Each module consists of....

![Module Diagram](module-diagram.svg)

