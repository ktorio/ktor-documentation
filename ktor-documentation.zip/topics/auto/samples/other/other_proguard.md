[//]: # (title: Proguard)
[//]: # (category: samples)
[//]: # (caption: Proguard)

Browse the source code on GitHub: [ktor-samples-proguard](https://github.com/ktorio/ktor-samples/tree/master/other/proguard)

{% include sample.html paths='
    other/proguard/build.gradle,
    other/proguard/src/HelloApplication.kt,
' %}