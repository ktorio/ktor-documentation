[//]: # (title: Reverse Proxy)
[//]: # (category: samples)
[//]: # (caption: Reverse Proxy and Asynchronous Streaming using Ktor Client and Server)

Browse the source code on GitHub: [ktor-samples-proguard](https://github.com/ktorio/ktor-samples/tree/master/other/reverse-proxy)

{% include sample.html paths='
    other/reverse-proxy/src/ReverseProxyApplication.kt,
' %}