[//]: # (title: Multiple Connectors)
[//]: # (category: samples)
[//]: # (caption: Multiple Connectors)

Browse the source code on GitHub: [ktor-samples-multiple-connectors](https://github.com/ktorio/ktor-samples/tree/master/other/multiple-connectors)

{% include sample.html paths='
    other/multiple-connectors/src/Main.kt,
    other/multiple-connectors/test/MultiportsAppTest.kt,
' %}