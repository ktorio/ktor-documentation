[//]: # (title: RX)
[//]: # (category: samples)
[//]: # (caption: Reactive eXtensions)

Browse the source code on GitHub: [ktor-samples-rx](https://github.com/ktorio/ktor-samples/tree/master/other/rx)

{% include sample.html paths='
    other/rx/src/RxApplication.kt,
' %}