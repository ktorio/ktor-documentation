[//]: # (title: File Listing)
[//]: # (category: samples)
[//]: # (caption: File Listing)

Browse the source code on GitHub: [ktor-samples-filelisting](https://github.com/ktorio/ktor-samples/tree/master/other/filelisting)

{% include sample.html paths='
    other/filelisting/src/FileListingApplication.kt,
' %}