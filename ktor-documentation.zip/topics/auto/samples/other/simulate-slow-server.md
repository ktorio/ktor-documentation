[//]: # (title: Simulate Slow Server)
[//]: # (category: samples)
[//]: # (caption: Simulate Slow Server)

Browse the source code on GitHub: [ktor-samples-simulate-slow-server](https://github.com/ktorio/ktor-samples/tree/master/other/simulate-slow-server)

{% include sample.html paths='
    other/simulate-slow-server/src/SimulateSlowServerApplication.kt,
' %}