[//]: # (title: Redirect with Exception)
[//]: # (category: samples)
[//]: # (caption: Redirect with Exception)

Browse the source code on GitHub: [ktor-samples-redirect-with-exception](https://github.com/ktorio/ktor-samples/tree/master/other/redirect-with-exception)

{% include sample.html paths='
    other/redirect-with-exception/src/RedirectWithExceptionApplication.kt,
' %}