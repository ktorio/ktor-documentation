[//]: # (title: Maven with Netty)
[//]: # (category: samples)
[//]: # (caption: Maven with Netty)

Browse the source code on GitHub: [ktor-samples-maven-netty](https://github.com/ktorio/ktor-samples/tree/master/other/maven-netty)

{% include sample.html paths='
    other/maven-netty/pom.xml,
    other/maven-netty/src/HelloApplication.kt,
    other/maven-netty/resources/application.conf
' %}