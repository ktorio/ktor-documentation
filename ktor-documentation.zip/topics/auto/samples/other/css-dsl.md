[//]: # (title: CSS DSL)
[//]: # (category: samples)
[//]: # (caption: CSS DSL)

Browse the source code on GitHub: [ktor-samples-css-dsl](https://github.com/ktorio/ktor-samples/tree/master/other/css-dsl)

{% include sample.html paths='
    other/css-dsl/src/CssDslApplication.kt,
    other/css-dsl/build.gradle,
' %}