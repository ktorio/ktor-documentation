[//]: # (title: Structured Logging)
[//]: # (category: samples)
[//]: # (caption: Structured Logging)

Browse the source code on GitHub: [ktor-samples-structured-logging](https://github.com/ktorio/ktor-samples/tree/master/other/structured-logging)

{% include sample.html paths='
    other/structured-logging/src/Application.kt,
    other/structured-logging/src/StructuredLogging.kt,
' %}