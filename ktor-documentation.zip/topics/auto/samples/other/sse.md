[//]: # (title: SSE (Server-Sent Events))
[//]: # (category: samples)
[//]: # (caption: SSE (Server-Sent Events))

Browse the source code on GitHub: [ktor-samples-sse](https://github.com/ktorio/ktor-samples/tree/master/other/sse)

{% include sample.html paths='
    other/sse/src/SseApplication.kt,
' %}