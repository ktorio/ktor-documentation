[//]: # (title: Client Multipart)
[//]: # (category: samples)
[//]: # (caption: Client Multipart)

Browse the source code on GitHub: [ktor-samples-client-multipart](https://github.com/ktorio/ktor-samples/tree/master/other/client-multipart)

{% include sample.html paths='
    other/client-multipart/src/MultipartApp.kt,
' %}