[//]: # (title: Client Tools)
[//]: # (category: samples)
[//]: # (caption: Client Tools)

Browse the source code on GitHub: [ktor-samples-client-tools](https://github.com/ktorio/ktor-samples/tree/master/other/client-tools)

{% include sample.html paths='
    other/client-tools/src/ToolsApp.kt,
' %}