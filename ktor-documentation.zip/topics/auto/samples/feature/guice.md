[//]: # (title: Guice)
[//]: # (category: samples)
[//]: # (permalink: /samples/feature/guice.html)
[//]: # (caption: Example of Using Guice Dependency Injection)
[//]: # (redirect_from: redirect_from)
[//]: # (- /samples/guice.html: - /samples/guice.html)

Browse the source code on GitHub: [ktor-samples-guice](https://github.com/ktorio/ktor-samples/tree/master/feature/guice)

{% include sample.html paths = '
    feature/guice/src/GuiceApplication.kt,
    feature/guice/test/GuiceApplicationTest.kt
' %}