[//]: # (title: Custom Feature)
[//]: # (category: samples)
[//]: # (permalink: /samples/feature/custom-feature.html)
[//]: # (caption: Example of a Custom Feature)
[//]: # (redirect_from: redirect_from)
[//]: # (- /samples/custom-feature.html: - /samples/custom-feature.html)

Browse the source code on GitHub: [ktor-samples/feature/custom-feature](https://github.com/ktorio/ktor-samples/tree/master/feature/custom-feature)

{% include sample.html 
    paths='feature/custom-feature/src/CustomHeader.kt,feature/custom-feature/src/FeatureApplication.kt' %}