[//]: # (title: Metrics)
[//]: # (category: samples)
[//]: # (permalink: /samples/feature/metrics.html)
[//]: # (caption: Example of Wiring up Metrics)
[//]: # (redirect_from: redirect_from)
[//]: # (- /samples/metrics.html: - /samples/metrics.html)

Browse the source code on GitHub: [ktor-samples-metrics](https://github.com/ktorio/ktor-samples/blob/master/feature/metrics/src/MetricsApplication.kt)

{% include sample.html paths='
    feature/metrics/src/MetricsApplication.kt
' %}