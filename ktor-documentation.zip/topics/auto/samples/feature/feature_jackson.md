[//]: # (title: Jackson)
[//]: # (category: samples)
[//]: # (permalink: /samples/feature/jackson.html)
[//]: # (caption: Example of Serving JSON using Jackson)
[//]: # (redirect_from: redirect_from)
[//]: # (- /samples/jackson.html: - /samples/jackson.html)

Browse the source code on GitHub: [ktor-samples-jackson](https://github.com/ktorio/ktor-samples/tree/master/feature/jackson)

{% include sample.html paths = 'feature/jackson/src/JacksonApplication.kt' %}