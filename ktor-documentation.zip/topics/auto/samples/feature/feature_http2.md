[//]: # (title: HTTP/2)
[//]: # (category: samples)
[//]: # (permalink: /samples/feature/http2.html)
[//]: # (caption: Example of Enabling HTTP/2 Support)
[//]: # (redirect_from: redirect_from)
[//]: # (- /samples/http2.html: - /samples/http2.html)

Browse the source code on GitHub: [ktor-samples-http2](https://github.com/ktorio/ktor-samples/blob/master/feature/http2-push)

{% include sample.html paths = '
    feature/http2-push/src/Http2PushApplication.kt,
    feature/http2-push/src/Main.kt
' %}