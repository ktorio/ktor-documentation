[//]: # (title: GSON)
[//]: # (category: samples)
[//]: # (permalink: /samples/feature/gson.html)
[//]: # (caption: Example of Serving JSON using GSON)
[//]: # (redirect_from: redirect_from)
[//]: # (- /samples/gson.html: - /samples/gson.html)

Browse the source code on GitHub: [ktor-samples-gson](https://github.com/ktorio/ktor-samples/tree/master/feature/gson)

{% include sample.html paths = '
    feature/gson/src/GsonApplication.kt
' %}