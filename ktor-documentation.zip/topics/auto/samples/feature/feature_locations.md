[//]: # (title: Locations)
[//]: # (category: samples)
[//]: # (permalink: /samples/feature/locations.html)
[//]: # (caption: Example of Using Typed Locations)
[//]: # (redirect_from: redirect_from)
[//]: # (- /samples/locations.html: - /samples/locations.html)

Browse the source code on GitHub: [ktor-samples-locations](https://github.com/ktorio/ktor-samples/tree/master/feature/locations)

{% include sample.html paths='
    feature/locations/src/LocationsApplication.kt
' %}