[//]: # (title: Static)
[//]: # (category: samples)
[//]: # (permalink: /samples/feature/static.html)
[//]: # (caption: Example of Serving Static Files)
[//]: # (redirect_from: redirect_from)
[//]: # (- /samples/static.html: - /samples/static.html)

Browse the source code on GitHub: [ktor-samples-static](https://github.com/ktorio/ktor-samples/tree/master/feature/static-content)

{% include sample.html paths='
    feature/static-content/src/StaticContentApplication.kt
' %}