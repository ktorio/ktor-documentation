[//]: # (title: POST)
[//]: # (category: samples)
[//]: # (permalink: /samples/feature/post.html)
[//]: # (caption: Example of Posting Data with Forms)
[//]: # (redirect_from: redirect_from)
[//]: # (- /samples/post.html: - /samples/post.html)

Browse the source code on GitHub: [ktor-samples-post](https://github.com/ktorio/ktor-samples/blob/master/feature/post)

{% include sample.html paths='
    feature/post/src/PostApplication.kt
' %}