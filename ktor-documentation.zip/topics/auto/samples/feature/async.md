[//]: # (title: Asynchronous)
[//]: # (category: samples)
[//]: # (permalink: /samples/feature/async.html)
[//]: # (caption: Example of Asynchronous Responses)
[//]: # (redirect_from: redirect_from)
[//]: # (- /samples/async.html: - /samples/async.html)

Browse the source code on GitHub: [ktor-samples/feature/async](https://github.com/ktorio/ktor-samples/tree/master/feature/async)

{% include sample.html paths = 'feature/async/src/AsyncApplication.kt' %}