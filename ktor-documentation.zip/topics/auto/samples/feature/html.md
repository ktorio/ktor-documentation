[//]: # (title: Html)
[//]: # (category: samples)
[//]: # (permalink: /samples/feature/html.html)
[//]: # (caption: Example of Using Html Builders)
[//]: # (redirect_from: redirect_from)
[//]: # (- /samples/html.html: - /samples/html.html)

Browse the source code on GitHub: [ktor-samples-html](https://github.com/ktorio/ktor-samples/tree/master/feature/html-widget)

{% include sample.html paths = '
    feature/html-widget/src/HtmlWidgetApplication.kt
' %}