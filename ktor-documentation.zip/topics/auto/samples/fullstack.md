[//]: # (title: FullStack)
[//]: # (category: samples)
[//]: # (permalink: /samples/fullstack.html)
[//]: # (caption: Example of a FullStack Application)

Browse the source code on GitHub: [Kotlin/kotlin-fullstack-sample](https://github.com/Kotlin/kotlin-fullstack-sample)