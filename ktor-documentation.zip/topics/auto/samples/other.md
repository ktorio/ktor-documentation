[//]: # (title: Other)
[//]: # (caption: Other)
[//]: # (category: samples)
[//]: # (permalink: /samples/other.html)
[//]: # (children: /samples/other/)

{% include list-children.html %}