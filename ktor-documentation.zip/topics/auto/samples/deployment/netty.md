[//]: # (title: Netty)
[//]: # (category: samples)
[//]: # (permalink: /samples/deployment/netty.html)
[//]: # (caption: Netty)
[//]: # (redirect_from: redirect_from)
[//]: # (- /samples/hello.html: - /samples/hello.html)

Browse the source code on GitHub: [ktor-samples-hello](https://github.com/ktorio/ktor-samples/tree/master/deployment/netty/)

{% include sample.html paths = '
    deployment/netty/src/HelloApplication.kt
' %}