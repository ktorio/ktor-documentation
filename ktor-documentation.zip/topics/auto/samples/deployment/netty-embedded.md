[//]: # (title: Embedded)
[//]: # (category: samples)
[//]: # (permalink: /samples/deployment/netty-embedded.html)
[//]: # (caption: Example of Creating an Embedded Application)
[//]: # (redirect_from: redirect_from)
[//]: # (- /samples/embedded.html: - /samples/embedded.html)

Browse the source code on GitHub: [ktor-samples-embedded](https://github.com/ktorio/ktor-samples/tree/master/deployment/netty-embedded)

{% include sample.html paths = '
    deployment/netty-embedded/src/Main.kt,
    deployment/netty-embedded/src/HelloApplication.kt
' %}