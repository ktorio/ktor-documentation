[//]: # (title: HttpBin)
[//]: # (category: samples)
[//]: # (permalink: /samples/app/httpbin.html)
[//]: # (caption: Showcase of Basic Features)
[//]: # (redirect_from: redirect_from)
[//]: # (- /samples/httpbin.html: - /samples/httpbin.html)

Browse the source code on GitHub: [ktor-samples-httpbin](https://github.com/ktorio/ktor-samples/tree/master/app/httpbin)

{% include sample.html paths = '
    app/httpbin/src/HttpBinApplication.kt,
    app/httpbin/src/HttpBinError.kt,
    app/httpbin/src/HttpBinResponse.kt,
    app/httpbin/src/Helpers.kt
' %}