[//]: # (title: Kweet)
[//]: # (category: samples)
[//]: # (permalink: /samples/app/kweet.html)
[//]: # (caption: Example of Twitter-like Application)
[//]: # (redirect_from: redirect_from)
[//]: # (- /samples/kweet.html: - /samples/kweet.html)

Browse the source code on GitHub: [ktor-samples-kweet](https://github.com/ktorio/ktor-samples/tree/master/app/kweet)