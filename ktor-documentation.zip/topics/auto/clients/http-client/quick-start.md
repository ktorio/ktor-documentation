[//]: # (title: Quick start)
[//]: # (caption: HTTP client quick start)
[//]: # (category: clients)
[//]: # (permalink: /clients/http-client/quick-start.html)
[//]: # (children: /clients/http-client/quick-start/)
[//]: # (ktor_version_review: 1.2.0)

Following this guide you'll learn how to setup ktor HTTP client and make your first request:
{% include children_list.html context=page.children %}