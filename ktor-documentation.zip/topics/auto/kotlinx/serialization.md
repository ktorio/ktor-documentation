[//]: # (title: kotlinx.serialization)
[//]: # (caption: "kotlinx.serialization)
[//]: # (category: kotlinx)
[//]: # (toc: true)
[//]: # (permalink: /kotlinx/serialization.html)
[//]: # (ktor_version_review: 1.0.0)

Do you need to send a message from Native or JVM to JavaScript or over the network?
Do you need to store a class in file and retrieve it later?
`kotlinx.serialization` allows you to do it.

`kotlinx.serialization` is OpenSource and you can find it at GitHub: <https://github.com/Kotlin/kotlinx.serialization>