[//]: # (title: kotlinx.atomicfu)
[//]: # (caption: "kotlinx.atomicfu)
[//]: # (category: kotlinx)
[//]: # (toc: true)
[//]: # (permalink: /kotlinx/atomicfu.html)
[//]: # (ktor_version_review: 1.0.0)

`kotlinx.atomicfu` is OpenSource and you can find it at GitHub: <https://github.com/Kotlin/kotlinx.atomicfu>{ target="_blank"}