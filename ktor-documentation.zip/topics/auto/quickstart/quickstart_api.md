[//]: # (title: API Docs)
[//]: # (caption: API Documentation)
[//]: # (category: quickstart)
[//]: # (permalink: /quickstart/api.html)
[//]: # (skip_pdf: true)
[//]: # (ktor_version_review: 1.0.0)

<!--<https://api.ktor.io/>-->

**NOTE: You can also access the API Documentation Website here: [https://api.ktor.io/](https://api.ktor.io/){target="_blank"}**

<iframe src="https://api.ktor.io/{{ site.ktor_version }}/" style="border:1px solid #343a40;width:100%;height:574px;"></iframe>