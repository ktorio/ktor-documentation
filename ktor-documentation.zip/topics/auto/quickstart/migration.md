[//]: # (title: Migration)
[//]: # (caption: Migration)
[//]: # (category: quickstart)
[//]: # (permalink: /quickstart/migration.html)
[//]: # (children: /quickstart/migration/)
[//]: # (redirect_from: redirect_from)
[//]: # (- /quickstart/changelog.html: - /quickstart/changelog.html)
[//]: # (toc: false)
[//]: # (ktor_version_review: 1.0.0)

{% include list-children.html %}