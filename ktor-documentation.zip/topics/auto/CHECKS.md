On new releases check:

* Versions at `_config.yml`
* New page at `/quickstart/migration.html`
* Review `/quickstart/artifacts.html`
* Review `/quickstart/faq.html`
* Execute `./checkLinks.kt` after changes