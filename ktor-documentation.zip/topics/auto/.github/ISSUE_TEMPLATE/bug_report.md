[//]: # (name: Bug report)
[//]: # (about: Please read Important notice below)
[//]: # (title: '')
[//]: # (labels: '')
[//]: # (assignees: '')

## Important notice 

We're currently in the process of migrating issues over to [YouTrack](https://youtrack.jetbrains.com/issues/KTOR) which will not allow provide us with many benefits but also allow better management of issues. We'd really appreciate if you would log your bug directly on YouTrack. If you're not registered, do not worry, as you can log in using your GitHub account. 

[Click here to report a new bug](https://youtrack.jetbrains.com/newIssue?project=KTOR&c=Subsystem%20Docs)