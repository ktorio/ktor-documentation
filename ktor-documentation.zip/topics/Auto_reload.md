[//]: # (title: Auto reload)

During development, it is important to have a fast feedback loop cycle. Often, restarting the server can take some time which is why Ktor provides a 
basic auto-reload facility that reloads our Application classes.

