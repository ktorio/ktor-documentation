Link to build server

https://buildserver.labs.intellij.net/buildConfiguration/Documentation_TransitioningProducts_KtorDocsWithSupernova?

Link to Docs preview

https://helpserver.labs.jb.gg/help/ktor-supernova/1.3/welcome.html

Diagram tool

https://apps.diagram.net

