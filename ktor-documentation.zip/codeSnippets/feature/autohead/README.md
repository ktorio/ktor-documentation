# AutoHeadResponse

Sample project for [Ktor](https://ktor.io) showing AutoHeadResponse functionality.

## Running

Execute this command in the repository's root directory to run this sample:

```bash
./gradlew :autohead:run
```
 
And make a HEAD request to [http://localhost:8080/home] to see the response.
