# Simulate Slow Server

Small application simulating a slow server by creating a custom interceptor for [Ktor](https://ktor.io)

## Running

Execute this command in the repository's root directory to run this sample:

```bash
./gradlew :simulate-slow-server:run
```
 
And navigate to [http://localhost:8080/](http://localhost:8080/) to see the sample home page.  