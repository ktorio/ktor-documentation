# Client Multipart

Sample project for [Ktor](https://ktor.io) showing how to send multipart data from the HttpClient.

## Running

Execute this command in the repository's root directory to run this sample:

```bash
./gradlew :client-multipart:run
```
 
And navigate to [http://localhost:8080/](http://localhost:8080/) to see the sample home page.  
