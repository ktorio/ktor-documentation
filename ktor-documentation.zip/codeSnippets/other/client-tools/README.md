# Client Tools

Sample project for [Ktor](https://ktor.io) showing several useful extension methods not included in Ktor itself.

## Running

Execute this command in the repository's root directory to run this sample:

```bash
./gradlew :client-tools:run
```

Note: for this sample to work you need to open a server in your localhost at port 8080.